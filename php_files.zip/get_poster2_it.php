<?php
    // <!-- 상위 카테고리 선택 시, 게시물 페이지 -->
    include "dbcon.php";

    mysqli_query($con, "set names utf8");

    // 상위 카테고리를 선택하여 해당 카테고리 값을 가져옴.
    // $parentCategory = $_POST("poster_parentCategory");
    $parentCategory = 'ITㆍ프로그래밍';

    // 상위 카테고리의
    // 게시물id, 제목, 시작일, 종료일 가져오기(검색)
    $sql_poster = mysqli_query($con, 
        "SELECT poster_id, poster_parentCategory, poster_title, poster_content, poster_startTime, poster_endTime, poster_registrant
        FROM poster
        WHERE poster_parentCategory = '$parentCategory'
        ORDER BY poster_id DESC");

    // 상위 카테고리의
    // 경매가 가격 가져오기(검색)
    $sql_price = mysqli_query($con, 
        "SELECT poster.poster_parentCategory, poster.poster_id, reply.poster_id, reply.reply_id, reply.reply_content
        FROM poster
        	INNER JOIN reply
            ON poster.poster_id = reply.poster_id
        WHERE poster_parentCategory = '$parentCategory'
        ORDER BY poster.poster_id DESC");
    


    // parentCategory, poster_id, title, startTime, endTime
    $poster_infoList = [];  // 게시물 정보 리스트
    while($row = mysqli_fetch_array($sql_poster)){  // $sql_poster로 가져온 정보를 한 행씩 $row에 담는다.(없으면 반복 중지)
        $poster_info = [];      // 게시물 세부 정보 배열
        $poster_info["poster_id"] = $row[0];
        $poster_info["parentCategory"] = $row[1];
        $poster_info["title"] = $row[2];
        $poster_info["content"] = $row[3];
        $poster_info["startTime"] = $row[4];
        $poster_info["endTime"] = $row[5];
        $poster_info["registrant"] = $row[6];
        array_push($poster_infoList, $poster_info);         // 2차원 배열로 만듬.
        // array_push($poster_info, $row[0], $row[1], $row[2], $row[3], $row[4], $row[5], $row[6]);  // 각 데이터를 한 배열에 넣어주고,
    }


    // // 경매가 가격 리스트
    // $price_info = [];
    // $price_list = [];   // 경매가 정보가 있는 배열
    // while($row = mysqli_fetch_array($sql_price)){
    //     $key = $row[1];
    //     $value = $row[4];
    //     $price_id = [];
    //     array_push($price_id, $key, $value);
    //     array_push($price_list, $price_id);
    // }

    // 경매가 가격 리스트
    $price_info = [];
    $price_list = [];   // 경매가 정보가 있는 배열
    while($row = mysqli_fetch_array($sql_price)){
        $price_info["poster_id"] = $row[1];
        $price_info["reply_content"] = $row[4];
        // $price_id = [];
        // array_push($price_id, $key, $value);
        // array_push($price_list, $price_id);
        array_push($price_list, $price_info);
    }


    // $max = 0;
    // for($i=0; $i<count($price_list)-1; $i++){
    //     $max = $price_list[$i][0] > $price_list[$i+1][0] ? $price_list[$i][0] : $price_list[$i+1][0];
    // }

    // echo $max;

    // // 평균 가격 계산
    // $price_avg = 0;     // 평균 계산을 위한 변수
    // $price_map = [];   // 게시글에 따른 평균가격 리스트
    // for($i=1; $i<=$max; $i++){
    //     $cnt = 0;     // 같은 게시글 id 확인을 위한 카운트
    //     $price_sum = 0; // 합계 초기값
    //     for($j=0; $j<count($price_list); $j++){
    //         if($i == $price_list[$j][0]){  // 전체 훑어봤을 때, 같은 게시물일 경우...
    //             $price_sum = $price_sum + $price_list[$j][1];  // 같은 게시물일 경우, 가격을 합친다.
    //             $cnt++; // 카운트값 증가
    //             $key = $price_list[$j][0]; // 해당 게시글의 id를 키 값으로 넣어준다.
    //         }
    //     }
    //     if($cnt == 0){  // 카운트 값이 0이면 정지
    //         continue;
    //     }
    //     $price_avg = $price_sum / $cnt;             // 평균 구하기
    //     $value = $price_avg;                        // 해당 게시글의 id에 맞는 value 값을 지정해준다.
    //     $price_map[$key] = $value;
    // }


    // 보내줄 값들
    $response = array();
    $response["poster_infoList"] = $poster_infoList;
    // $response["price_list"] = $price_list;
    
    mysqli_close($con);
   
    echo json_encode($response, JSON_UNESCAPED_UNICODE);
?> 