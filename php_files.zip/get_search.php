<?php
    $db_host = "localhost";
    $db_user = "strawberry";
    $db_password = "ckdgns6078!";
    $db_name = "strawberry";

    $con = mysqli_connect($db_host,$db_user,$db_password,$db_name);
    mysqli_query($con,"SET NAMES utf8");

    $title =$_POST["poster_title"];
    $a = "%";
    $title2 = $a.$title.$a;


    $sql_title = "SELECT poster_id,poster_registrant,poster_parentCategory,poster_title,poster_content,poster_startTime,poster_endTime,choose,finish
                  FROM poster WHERE poster_title LIKE '$title2'";
    $query_title = mysqli_query($con,$sql_title);

    $title_array = array();
    $main_array = array();
    
    while($array = mysqli_fetch_array($query_title)){
        $title_array["poster_id"]=$array[0];
        $title_array["poster_registrant"]=$array[1];
        $title_array["poster_parentCategory"]=$array[2];
        $title_array["poster_title"]=$array[3];
        $title_array["poster_content"]=$array[4];
        $title_array["poster_statTime"]=$array[5];
        $title_array["poster_endTime"]=$array[6];
        $title_array["choose"]=$array[7];
        $title_array["finish"]=$array[8];
        array_push($main_array,$title_array);

    }
    mysqli_close($con);
    
    $response = array();
    $response["success"]=true;
    $response["title_array"]=$main_array;

    echo json_encode($response,JSON_UNESCAPED_UNICODE);


    




?>