<?php

    //내가 받을 거-> 전화번호, 이메일, 경력사항, 이름
    $db_host="localhost";
    $db_user="strawberry";
    $db_password="ckdgns6078!";
    $db_name="strawberry";

    $con = mysqli_connect($db_host,$db_user,$db_password,$db_name);
    mysqli_query($con, "set names utf8");

    $user_nickName =$_POST["user_nickName"];
    $user_career =$_POST["user_career"];
    $user_phoneNum =$_POST["user_phoneNum"];
    $user_email =$_POST["user_email"];

    //UPDATE 테이블명 SET 컬럼1 = 수정값1 [, 컬럼2 = 수정값2 ...] [WHERE 조건];
    $sql = "UPDATE user_info SET user_career = '$user_career',user_phoneNum = '$user_phoneNum',user_email = '$user_email' WHERE user_nickName = '$user_nickName'";
    $query =mysqli_query($con,$sql);
    
    mysqli_close($con);

    $response = array();
    $response["success"] = true;
    
    echo json_encode($response);


    ?>