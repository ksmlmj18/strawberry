<?php
    // <!-- 상세 페이지 -->
    include "dbcon.php";

    mysqli_query($con, "set names utf8");
    
    // 요청 받은 게시글 id
    $poster_id = $_POST("poster_id");
    // $poster_id = "test01";

    // 게시글 정보, 댓글 정보 가져오기
    // 필요한 정보들만 정제하기(게시글 id, 제목, 상위 카테고리, 시작일, 종료일, 상세내용, 댓글 id, 사용자 id, 댓글 contnet, 댓글 작성날짜)
    $sql_poster = mysqli_query($con, 
        "SELECT p.poster_id, p.poster_title, p.poster_parentCategory
            , p.poster_startTime, p.poster_endTime, p.poster_content
            , r.reply_id, r.user_id, r.reply_content, r.reply_regdate
        FROM poster p, reply r
        WHERE p.poster_id = '$poster_id'");


    $page_infoList = [];
    // 정제된 정보 행 단위로 정제하기
    while($row = mysqli_fetch_array($sql_poster)){
        for($i = 0; $i<10; $i++){
            array_push($page_infoList, $row[$i]);
        }
    }

    // 보낼 데이터들
    $response = [];
    $response["success"] = true;
    $response["page_infoList"] = $page_infoList;

    mysqli_close($con);

    echo json_encode($response, JSON_UNESCAPED_UNICODE);
?>