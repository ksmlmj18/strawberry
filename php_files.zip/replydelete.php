<?php
    $db_host = "localhost";
    $db_user = "strawberry";
    $db_password = "ckdgns6078!";
    $db_name = "strawberry";

    $con =mysqli_connect($db_host,$db_user,$db_password,$db_name);
    mysqli_query($con,'SET NAME utf8');

    $poster_id = $_POST["poster_id"];
    $multisql = "DELETE FROM poster WHERE poster_id = '$poster_id';
                 DELETE FROM reply WHERE poster_id = '$poster_id'"; 
    $result = mysqli_multi_query($con,$multisql);

    $response = array();
    $response["success"]=true;
    mysqli_close($con);

    echo json_encode($response);

?>