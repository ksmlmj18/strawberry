<?php
    $db_host = "localhost";
    $db_user = "strawberry";
    $db_password = "ckdgns6078!";
    $db_name = "strawberry";

    $con = mysqli_connect($db_host,$db_user,$db_password,$db_name);
    mysqli_query($con,'SET NAMES utf8');


    $user_id=$_POST["user_id"];
    $user_phoneNum=$_POST["user_phoneNum"];
    $user_email=$_POST["user_email"];
    $user_career=$_POST["user_career"];

    $sql = "UPDATE user_info SET user_phoneNum ='$user_phoneNum',user_email='$user_email',user_career='$user_career' 
            WHERE user_id = '$user_id'";

    $result =mysqli_query($con,$sql);

    $response = array();
    $response["success"]=true;
    mysqli_close($con);

    echo json_encode($response);
?>