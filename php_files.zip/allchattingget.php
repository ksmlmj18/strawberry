<?php
    //server.php에 있는 모든 코드 및 변수를 가져와서 쓸 수 있음.
    // chat_infoList
    $chatid_array = array();  //chat_id array
    $person_array = array(); //대화 상대 array
    $day_array = array();   // 날짜 array
    $time_array = array();  // 시간 array
    $content_array = array();// 대화내용 

    $db_host="localhost";
    $db_user="strawberry";
    $db_password="ckdgns6078!";
    $db_name="strawberry";

    $con = mysqli_connect($db_host,$db_user,$db_password,$db_name);
    mysqli_query($con, "set names utf8");

    $user_id = $_POST["user_id"];
    //server.php 파일에 가지에서 include 해온 아이디로 닉네임을 찾기
    $sql_nickName = "SELECT user_nickName FROM user_info WHERE user_id ='$user_id'";
    $query_nickName = mysqli_query($con,$sql_nickName);
    $nickName_array = mysqli_fetch_array($query_nickName);
    $nickName = $nickName_array['user_nickName'];    // 찾은 닉네임
    
    // chat_id 찾기 
    $sql_chatid ="SELECT DISTINCT chat_id FROM chat WHERE sender = '$nickName' or getter = '$nickName'";
    $query_chatid = mysqli_query($con,$sql_chatid);
    //찾은 chat_id 배열에 저장해서 크기 찾기
    while($chat_id_array = mysqli_fetch_array($query_chatid)){
      array_push($chatid_array,$chat_id_array[0]);  
  }
  $count_array = count($chatid_array);
    //---------------------------------------------------------
      //chat_id 만큼 찾아서 대화하는 상대 닉네임 찾기



      // $chatid_array = array();  //chat_id array
      // $person_array = array(); //대화 상대 array
      // $day_array = array();   // 날짜 array
      // $time_array = array();  // 시간 array
      // $content_array = array();// 대화내용 
  for($i = 0 ; $i<$count_array;$i++){                                                  //3번실행시 안됨 0 =1,1=2,2=3
    $sql_sender= "SELECT DISTINCT getter FROM chat WHERE sender = '$nickName' AND chat_id = '$chatid_array[$i]'";
    $query_sender = mysqli_query($con,$sql_sender);
    $sender_array = mysqli_fetch_array($query_sender);
    if($query_sender->num_rows>0){
    array_push($person_array,$sender_array[0]);     
    }else{
      $sql_getter = "SELECT DISTINCT sender FROM chat WHERE getter = '$nickName' AND chat_id ='$chatid_array[$i]'";
      $query_sender = mysqli_query($con,$sql_getter);
      $getter_array = mysqli_fetch_array($query_sender);
      array_push($person_array,$getter_array[0]);     
    }     
  }



  // -------------------------
  // $userid_array = array(); 1,2,3 들어있음
  // 채팅목록에서 가장 큰 날짜 찾아오기
  for($i=0;$i<$count_array;$i++){
    $sql_day = "SELECT MAX(chat_day) FROM chat WHERE chat_id = '$chatid_array[$i]'";
    $query_day = mysqli_query($con,$sql_day);
    $last_day_array = mysqli_fetch_array($query_day);
    array_push($day_array,$last_day_array[0]);
  }


  // SELECT MAX(chat_time) FROM chat WHERE chat_day = ( SELECT MAX(chat_day) FROM chat WHERE chat_id =1);   
  // 채팅 목록에서 가장 큰 시간 찾아오기
  
  for($i=0;$i<$count_array;$i++){
    $sql_time = "SELECT MAX(chat_time) FROM chat WHERE chat_id ='$chatid_array[$i]' AND chat_day = (SELECT MAX(chat_day) FROM chat WHERE chat_id ='$chatid_array[$i]')";
    $query_time = mysqli_query($con,$sql_time);
    $find_time_array = mysqli_fetch_array($query_time);
    
    array_push($time_array,$find_time_array[0]);
  }

  //채팅 내용
  for($i=0;$i<$count_array;$i++){
    $sql_content = "SELECT chat_content FROM chat WHERE chat_id = '$chatid_array[$i]' AND chat_day = '$day_array[$i]' AND chat_time = '$time_array[$i]'";
    $query_content = mysqli_query($con,$sql_content);
    $find_content_array = mysqli_fetch_array($query_content);
    array_push($content_array,$find_content_array[0]);
  }     
    
    mysqli_close($con);
    
    $response1 = array();
    $response1["success"] = true;
    $chat_list = array();           //클라이언트에 보낼 배열
        
    $all = array();                //저장된 내용을 보내는 배열
    for($i =0; $i<$count_array;$i++){
        $all["chatid"]=$chatid_array[$i];
        $all["person"]=$person_array[$i];
        $all["day"]=$day_array[$i];
        $all["time"]=$time_array[$i];
        $all["content"]=$content_array[$i];
        array_push($chat_list,$all);
    }
    $response1 = array();
    $response1["success"] = true;
    $response1["chat_list"]=$chat_list;

    echo json_encode($response1,JSON_UNESCAPED_UNICODE);
?>