<?php
    // 안드로이드 -> 서버 -> DB 로그인하자마자 33334주기
    $db_host = "localhost";
    $db_user = "strawberry";
    $db_password = "ckdgns6078!";
    $db_name = "strawberry";
    
    $con = mysqli_connect($db_host,$db_user,$db_password,$db_name);
    mysqli_query($con, "SET NAMES utf8");

    $user_id = $_POST["user_id"];

    $sql_nickname = "SELECT user_nickName FROM user_info WHERE user_id ='$user_id'";
    $query_nickname = mysqli_query($con,$sql_nickname);
    $nickname_array = mysqli_fetch_array($query_nickname);
    $nickname = $nickname_array[0];
    
    //접속한 닉네임으로 받은 채팅 숫자 가져오기
    $sql_chat = "SELECT chat_content FROM chat WHERE getter = '$nickname'";
    $query_chat = mysqli_query($con,$sql_chat);
    $chatlist = array();

    while($chat_array = mysqli_fetch_array($query_chat)){
        array_push($chatlist,$chat_array[0]);
    }
    $count = count($chatlist);


    $response = array();
    $response["success"] = true;
    $response["chat_count"] = $count;
    echo json_encode($response, JSON_UNESCAPED_UNICODE);

?>