<?php
    // 마이페이지 -> 등록 댓글 게시물 목록 페이지
    // 로그인 한 uesr_id == reply.user_id 인 데이터
    // poster_id, poster_title, poster_starTime, poster_endTime, 평균 가격

    include "dbcon.php";

    mysqli_query($con, "set names utf8");

    // 로그인 한 user_id 값 받아오기
    // $user_id = $_POST["user_id"];
    $user_id = "fkrtms12";

    // 경매 댓글 달았던 게시글 정보
    $sql_reply = mysqli_query($con, 
        "SELECT poster.poster_id, reply.user_id, poster.poster_title, poster.poster_startTime, poster.poster_endTime
        FROM poster
        	INNER JOIN reply
            ON poster.poster_id = reply.poster_id
        WHERE reply.user_id = '$user_id'");


    // 해당 게시글 마다의 경매가 정보
    // 가격 정보 가져오기
    $sql_price = mysqli_query($con, 
    "SELECT reply.poster_id, reply.reply_id, reply.reply_content
    FROM poster
        INNER JOIN reply
        ON poster.poster_id = reply.poster_id
    WHERE reply.user_id = '$user_id'");


    // 내 경매 댓글 map
    $my_replyMap = [];
    while($row = mysqli_fetch_array($sql_reply)){
        $my_replyMap['poster_id'] = $row[0];
        $my_replyMap['id'] = $row[1];
        $my_replyMap['title'] = $row[2];
        $my_replyMap['startTime'] = $row[3];
        $my_replyMap['endTime'] = $row[4];
    }


    // 경매가 가격
    $price_info = [];
    $price_list = [];   // 경매가 정보가 있는 배열
    while($row = mysqli_fetch_array($sql_price)){
        $price_info["poster_id"] = $row[0];
        $price_info["reply_content"] = $row[2];
        array_push($price_list, $price_info);
    }

    
    $response = [];
    $response['success'] = true;
    $response['my_replyMap'] = $my_replyMap;
    $response['price_list'] = $price_list;

    mysqli_close($con);

    echo json_encode($response, JSON_UNESCAPED_UNICODE);
?>