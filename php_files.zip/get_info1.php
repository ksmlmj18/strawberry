<?php

    //내가 받을 거-> 전화번호, 이메일, 경력사항, 이름
    $db_host="localhost";
    $db_user="strawberry";
    $db_password="ckdgns6078!";
    $db_name="strawberry";

    $con = mysqli_connect($db_host,$db_user,$db_password,$db_name);
    mysqli_query($con, "set names utf8");

    $info = array();
    $main = array();
    $user_nickName = $_POST["user_nickName"];
    $sql_info = "SELECT user_name , user_phoneNum , user_email , user_career FROM user_info WHERE user_nickName = '$user_nickName'";
    $query_info = mysqli_query($con,$sql_info);
    
    while($array_info = mysqli_fetch_array($query_info)){
        $info["user_name"]=$array_info[0];
        $info["user_phoneNum"]=$array_info[1];
        $info["user_email"]=$array_info[2];
        $info["user_career"]=$array_info[3];
        array_push($main,$info);
    }
    mysqli_close($con);

    $response = array();
    $response["success"] = true;
    $response["info_array"] = $main;

    echo json_encode($response);
?>