<?php 
    $con = mysqli_connect("localhost", "strawberry", "ckdgns6078!", "strawberry");
    mysqli_query($con,'SET NAMES utf8');

    $user_id = isset($_POST["user_id"]) ? $_POST["user_id"] : "";
    $user_password = isset($_POST["user_pw"]) ? $_POST["user_pw"] : "";
    $user_name = isset($_POST["userName"]) ? $_POST["user_name"] : "";
    $user_phoneNum = isset($_POST["user_phoneNum"]) ? $_POST["user_phoneNum"] : "";
    $user_nickName = isset($_POST["user_nickName"]) ? $_POST["user_nickName"] : "";
    $user_email = isset($_POST["user_email"]) ? $_POST["user_email"] : "";
    $user_career = isset($_POST["user_career"]) ? $_POST["user_career"] : "";


    $statement = mysqli_prepare($con, "INSERT INTO user_info(user_id, user_pw, user_name, user_phoneNum, user_nickName, user_email, user_career) VALUES (?,?,?,?,?,?,?)");
    mysqli_stmt_bind_param($statement,"sssssss",$user_id, $user_pw, $user_name, $user_phoneNum, $user_nickName, $user_email, $user_career);
    mysqli_stmt_execute($statement);


    $response = array();
    $response["success"] = true;
 
   
    echo json_encode($response);
?>