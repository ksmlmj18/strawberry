<?php
    $db_host = "localhost";
    $db_user = "root";
    $db_password="78451212ab!@";
    $db_name = "mydb";

    $con = mysqli_connect($db_host, $db_user, $db_password, $db_name);

    $userID =$_POST["userID"];                   //아이디
    $userPassword = $_POST["userPassword"];      //비밀번호
    $userName = $_POST["username"];              //이름
    $userPhoneNum = $_POST["userPhoneNum"];      //번호
    $userEmail = $_POST["userEmail"];            //E-mail
    $userNickName = $_POST["userNickname"];      //닉네임
    $userCareer = $_POST["userCareer"];          //경력사항
    // $userSuccessNum = $_POST["usersuccessnum"];  //건수 ( 몇건을 했을지에 대한 내옹)
    // $userRating = $_POST["userrating"];          //평점 
    
    $sql = "INSERT INTO user_info(user_id, user_pw, user_name, user_phoneNum, user_nickName, user_email, user_career) VALUES(?,?,?,?,?,?,?)";
    $statement = mysqli_prepare($con,$sql);
    mysqli_stmt_bind_param($statement,"sssssss",$userID,$userPassword,$userName,$userPhoneNum,$userNickName,$userEmail,$userCareer);
    mysqli_stmt_execute($statement);
    
    $response = array();
    $response["success"] = true;

    echo json_encode($response);

    mysqli_close($con);
?>
