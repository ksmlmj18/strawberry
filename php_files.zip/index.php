<?php



    phpinfo();



?>