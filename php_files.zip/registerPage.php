<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form method = "post" action = "hi.php">
        아이디: <input type = "text" name = "user_id"><br>
        비밀번호: <input type = "password" name = "user_pw"><br>
        이름: <input type = "text" name = "user_name"><br>
        전화번호: <input type = "text" name = "user_phoneNum"><br>
        닉네임: <input type = "text" name = "user_nickName"><br>
        이메일: <input type = "text" name = "user_email"><br>
        경력사항: <input type = "text" name = "user_career"><br><br>
        <input type = "submit" value = "회원가입">
    </form>
</body>
</html>