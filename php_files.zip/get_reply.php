<?php
    // <!-- 댓글 경매 페이지 -->
    include "dbcon.php";

    mysqli_query($con, "set names utf8");
    
    // $dumy = $_POST["dumy"];

    // 댓글 경매 정보 가져오기
    $sql_reply = mysqli_query($con, 
        "SELECT user_nickName, poster_id, reply_id, reply_content, reply_regdate
        FROM reply");


    // 정보 맵 형식으로 다듬기
    $reply_infoList = [];
    while($row = mysqli_fetch_array($sql_reply)){
        $reply_info = [];
        $reply_info["nickName"] = $row[0];
        $reply_info["r_poster_id"] = $row[1];
        $reply_info["reply_id"] = $row[2];
        $reply_info["r_content"] = $row[3];
        $reply_info["regdate"] = $row[4];
        array_push($reply_infoList, $reply_info);
    }

    // 보낼 데이터들
    $response = [];
    $response["success"] = true;
    $response["reply_infoList"] = $reply_infoList;

    mysqli_close($con);

    echo json_encode($response, JSON_UNESCAPED_UNICODE);
?>