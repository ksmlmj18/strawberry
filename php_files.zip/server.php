<?php
    // $_SERVER['REMOTE_ADDR'] : 서버에 접속한 클라이언트의 ip를 가져온다.
    $db_host="localhost";
    $db_user="strawberry";
    $db_password="ckdgns6078!";
    $db_name="strawberry";
    $user_id =$_POST["user_id"];
    $ip =$_SERVER['REMOTE_ADDR'];
    $port = $_SERVER['SERVER_PORT'];
    // db 연결
    $con = mysqli_connect($db_host,$db_user,$db_password,$db_name);
    mysqli_query($con,'SET NAMES utf8');

    $sql_ip = "SELECT ip,port FROM user_ip WHERE id = '$user_id'";
    $query_ip = mysqli_query($con,$sql_ip);


    if($query_ip->num_rows>0){
        $sql_ipport = "UPDATE user_ip SET ip = '$ip',port = '$port' WHERE id ='$user_id'";
        mysqli_query($con,$sql_ipport);

    }else{
        $sql_newip = "INSERT INTO user_ip(id,ip,port) VALUE(?,?,?)";
        $statement = mysqli_prepare($con,$sql_newip);
        mysqli_stmt_bind_param($statement,"sss",$user_id,$ip,$port);
        mysqli_stmt_execute($statement);
    }

    mysqli_close($con);
    
    $response = array();
    $response["success"] = true;

    
    
    echo json_encode($response);


   
    
?>