<?php
    // < 스크랩 목록 가져오기 php >
    include 'dbcon.php';

    // 닉네임
    $user_nickName = $_POST["user_nickName"];

    // user_nickName을 받고
    // 해당 user_nickName이 갖고 있는 poster_id 건네주기
    $sql_search = "SELECT scrap_id, poster_id, user_nickName FROM scrap WHERE user_nickName = '$user_nickName'";
    $res_search = mysqli_query($con, $sql_search);

    $scrap_info = [];
    $scrap_infoList = [];
    while($row = mysqli_fetch_array($res_search)){
        $scrap_info["scrap_id"] = $row[0];
        $scrap_info["poster_id"] = $row[1];
        $scrap_info["user_nickName"] = $row[2];
        array_push($scrap_infoList, $scrap_info);
    }

    // $sql_nickName = "SELECT * FROM scrap";
    // $res_nickName = mysqli_query($con, $sql_nickName);

    // $all_info = [];
    // $all_infoList = [];
    // while($row2 = mysqli_fetch_array($res_nickName)){
    //     $all_info["user_nickName"] = $row2[0];
    //     $all_info["scrap_id"] = $row2[1];
    //     $all_info["user_nickName"] = $row2[2];
    //     array_push($all_infoList, $all_info);
    // }

    $response = [];
    $response["success"] = true;
    $response["scrap_infoList"] = $scrap_infoList;
    // $response["scrap_all_infoList"] = $all_infoList;

    echo json_encode($response, JSON_UNESCAPED_UNICODE);
?>