<?php
    $db_host="localhost";
    $db_user="strawberry";
    $db_password="ckdgns6078!";
    $db_name ="strawberry";
    // db 접속
    $con=mysqli_connect($db_host,$db_user,$db_password,$db_name);
    mysqli_query($con, 'SET NAMES utf8');
    //안드로이드에서 post받는 변수
    $user_nickName = $_POST["user_nickName"];
    $poster_id = $_POST["poster_id"];
    $reply_content = $_POST["reply_content"];
    $reply_year = $_POST["reply_year"];
    $reply_month = $_POST["reply_month"];
    $reply_day = $_POST["reply_day"];
    $underbar = "-";
    $reply_regdate = $reply_year . $underbar . $reply_month . $underbar . $reply_day;

    //reply_id 값을 얻기 위한 코드
    $max = "SELECT MAX(reply_id) FROM reply";
    $result = mysqli_query($con,$max);
    $row = mysqli_fetch_array($result);
    $reply_id = $row[0]+1;

    // POST받은 내용들 저장하는 코드
    $sql = "INSERT INTO reply(user_nickName,poster_id,reply_id,reply_content,reply_regdate)
                    VALUE (?,?,?,?,?)";
    $statement = mysqli_prepare($con,$sql);
    mysqli_stmt_bind_param($statement,"siiis",$user_nickName,$poster_id,$reply_id,$reply_content,$reply_regdate);
    mysqli_stmt_execute($statement);

    $response = array();
    $response["success"]=true;


    mysqli_close($con);
    echo json_encode($response);

?>