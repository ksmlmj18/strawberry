<?php
    $db_host="localhost";
    $db_user="strawberry";
    $db_password="ckdgns6078!";
    $db_name="strawberry";

    //db 연결
    $con = mysqli_connect($db_host,$db_user,$db_password,$db_name);
    mysqli_query($con, "set names utf8");
    $poster_id = $_POST["poster_id"];

    $sql_finish = "UPDATE poster SET finish =1 WHERE poster_id = '$poster_id'";
    $query_finish = mysqli_query($con,$sql_finish);
    

    $response = array();
    $response["success"]=true;
    mysqli_close($con);
    
    echo json_encode($response);

?>
