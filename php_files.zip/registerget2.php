<?php
    $db_host = "localhost";
    $db_user = "strawberry";
    $db_password="ckdgns6078!";
    $db_name = "strawberry";

    $con = mysqli_connect($db_host, $db_user, $db_password, $db_name);
    mysqli_query($con, 'SET NAMES utf8');

    $user_id = $_POST["user_id"];                   //아이디
    $user_pw = $_POST["user_pw"];      //비밀번호
    $user_name = $_POST["user_name"];              //이름
    $user_phoneNum = $_POST["user_phoneNum"];      //번호
    $user_nickName = $_POST["user_nickName"];      //닉네임
    $user_email = $_POST["user_email"];            //E-mail
    $user_career = $_POST["user_career"];          //경력사항
    // $user_successNum = $_POST["usersuccessnum"];  //건수 ( 몇건을 했을지에 대한 내옹)
    // $user_rating = $_POST["userrating"];          //평점
    // $user_picture = $_POST["userpicture"];
    
    $sql = "INSERT INTO user_info(user_id, user_pw, user_name, user_phoneNum, user_nickName, user_email, user_career) VALUES (?,?,?,?,?,?,?)";
    $statement = mysqli_prepare($con,$sql);
    mysqli_stmt_bind_param($statement,"sssssss",$user_id, $user_pw, $user_name, $user_phoneNum, $user_nickName, $user_email, $user_career);
    mysqli_stmt_execute($statement);
    
    $response = array();
    $response["success"] = true;
    
    mysqli_close($con);

    echo json_encode($response);
?>
