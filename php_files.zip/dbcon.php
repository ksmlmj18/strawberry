<?php
    // <!-- 서버 커넥터 -->
    $servername = "localhost";  // 서버이름
    $user = "strawberry";             // 사용자명
    $password = "ckdgns6078!"; // 패스워드
    $dbname = "strawberry";           // 데이터베이스 이름
    $con = mysqli_connect($servername, $user, $password, $dbname);   // MySQL 서버에 연결

    // 서버 접속 확인
    if(!$con){
        die("서버와의 연결 실패:".mysqli_connect_error);    // 연결에 실패한 이유 출력
    }
    // echo "서버와의 연결 성공 <br>";
?>