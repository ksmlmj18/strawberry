<?php
  	$con = mysqli_connect("localhost", "strawberry", "ckdgns6078!", "strawberry");
	mysqli_query($con, 'SET NAMES utf8');

	$userID =$_POST["userID"];                   //아이디
    $userPassword = $_POST["userPassword"];      //비밀번호
    $userName = $_POST["username"];              //이름
    $userPhoneNum = $_POST["userPhoneNum"];      //번호
    $userEmail = $_POST["userEmail"];            //E-mail
    $userNickName = $_POST["userNickname"];      //닉네임
    $userCareer = $_POST["userCareer"];          //경력사항

	$statement = mysqli_prepare($con, "INSERT INTO user_info(user_id, user_pw, user_name, user_phoneNum, user_email, user_nickName, user_career) VALUES (?,?,?,?,?,?,?)");
	mysqli_stmt_bind_param($statement, "sssssss", $userID, $userPassword, $userName, $userPhoneNum, $userNickName, $userEmail, $userCareer);
    mysqli_stmt_execute($statement);

	$response = array();
    $response["success"] = true;

    echo json_encode($response);
?>