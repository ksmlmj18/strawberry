<?php
    // < 마이페이지 -> 개인정보 수정 페이지 >
    // 로그인 한 user_id가 포함된 테이블
    // user_id, user_name, user_phoneNum, user_email, user_career 가져오기
    // [post 형식으로 가져오기]

    include "dbcon.php";

    mysqli_query($con, "set names utf8");

    // 로그인 한 user_id 값 받아오기
    $user_id = $_POST["user_id"];
    // $user_id = "fkrtms23";

    // DB의 user_id와 로그인 한 user_id가 같은 DB정보 가져오기
    $sql_user = mysqli_query($con,
        "SELECT user_id, user_name, user_phoneNum, user_email, user_career
        FROM user_info
        WHERE user_id = '$user_id'");

    
    $user_infoList = [];
    while($row = mysqli_fetch_array($sql_user)){
        $user_infoList['id'] = $row[0];
        $user_infoList['name'] = $row[1];
        $user_infoList['phoneNum'] = $row[2];
        $user_infoList['email'] = $row[3];
        $user_infoList['career'] = $row[4];
    }

    $response = [];
    $response["success"] = true;
    $response["user_infoList"] = $user_infoList;

    mysqli_close($con);

    echo json_encode($response, JSON_UNESCAPED_UNICODE);
?>