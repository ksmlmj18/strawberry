<?php
    $db_host="localhost";
    $db_user = "strawberry";
    $db_password = "ckdgns6078!";
    $db_name = "strawberry";

    $array = array();
    $chat_array=array();
   
    $con = mysqli_connect($db_host,$db_user,$db_password,$db_user);
    mysqli_query($con, 'SET NAMES utf8');

    $sender = $_POST["sender"];
    $getter = $_POST["getter"];

    $sql = "SELECT MAX(chat_count) FROM chat WHERE sender = '$sender' AND getter = '$getter' OR sender = '$getter' AND getter = '$sender'";
    $res_sql = mysqli_query($con, $sql);
    $row = mysqli_fetch_array($res_sql);

    
    mysqli_close($con);
    
    $response = array();
    if($row[0] != null){
        $response["success"]=true;
        $response["chat_count"] = $row[0];
    }else{
        $response["success"]=true;
        $response["chat_count"] = 0;
    }
    

    echo json_encode($response, JSON_UNESCAPED_UNICODE);
?>