<?php
    // < 마이페이지 -> 등록 경매 확인 페이지 >
    // 로그인 한 user_id == poster_registrant 인 정보
    // poster_id, poster_title, poster_startTime, poster_endTime, 평균 경매가

    include "dbcon.php";

    mysqli_query($con, "set names utf8");

    // 로그인 한 user_id 값 받아오기
    // $user_id = $_POST["user_id"];
    $user_id = "fkrtms12";

    // 게시글의 대한 정보
    $sql_auction = mysqli_query($con,
         "SELECT poster_id, poster_registrant, poster_title, poster_startTime, poster_endTime
         FROM poster
         WHERE poster_registrant = '$user_id'");

    
    // 해당 게시글 마다의 경매가 정보
    // 가격 정보 가져오기
    $sql_price = mysqli_query($con, 
    "SELECT reply.poster_id, reply.reply_id, reply.reply_content
        FROM poster
        INNER JOIN reply
        ON poster.poster_id = reply.poster_id
    WHERE poster_registrant = '$user_id'");


    // 게시글 정보
    $my_auction = [];
    while($row = mysqli_fetch_array($sql_auction)){
        $my_auction['id'] = $row[0];
        $my_auction['name'] = $row[1];
        $my_auction['title'] = $row[2];
        $my_auction['startTime'] = $row[3];
        $my_auction['endTime'] = $row[4];
    }


    // 경매가 가격
    $price_info = [];
    $price_list = [];   // 경매가 정보가 있는 배열
    while($row = mysqli_fetch_array($sql_price)){
        $price_info["poster_id"] = $row[0];
        $price_info["reply_content"] = $row[2];
        array_push($price_list, $price_info);
    }
    

    $response = [];
    $response['success'] = true;
    $response['my_auction'] = $my_auction;
    $response['price_list'] = $price_list;

    mysqli_close($con);

    echo json_encode($response, JSON_UNESCAPED_UNICODE);
?>