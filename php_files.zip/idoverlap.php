<?php
    $db_host="localhost";
    $db_user="strawberry";
    $db_password="ckdgns6078!";
    $db_name="strawberry";

    //db 연결
    $con = mysqli_connect($db_host,$db_user,$db_password,$db_name);
    $user_id = $_POST["user_id"];
    //db에서 실행할 sql문
    $sql = "SELECT user_id FROM user_info WHERE user_id='$user_id'";
    $result = mysqli_query($con,$sql);

    $response = array();

    if($result->num_rows>0){
        //true면 아이디 사용 가능
        $response["success"]=false;
    }else{
        //false면 아이디 사용 불가능
        $response["success"]=true;
    }

    echo json_encode($response);
    mysqli_close($con);
?>