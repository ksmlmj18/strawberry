<?php
    //채팅방 안에서 내용 가져오기
    $db_host="localhost";
    $db_user = "strawberry";
    $db_password = "ckdgns6078!";
    $db_name = "strawberry";

    $array = array();
    $chat_array=array();
   
    $con = mysqli_connect($db_host,$db_user,$db_password,$db_user);
    mysqli_query($con, 'SET NAMES utf8');

    $user_id =$_POST["user_id"];
    //검방전사
    $sql_nickName = "SELECT user_nickName FROM user_info WHERE user_id = '$user_id'";
    $query_nickName = mysqli_query($con,$sql_nickName);
    $nickName_array = mysqli_fetch_array($query_nickName);
    $nickName =$nickName_array[0];

    $sql_chat = "SELECT * FROM chat WHERE sender = '$nickName' OR getter='$nickName'";
    $query_chat = mysqli_query($con,$sql_chat);
    //$chat_id_array = mysqli_fetch_array($query_chat);

    mysqli_close($con);
    while($chat_id_array = mysqli_fetch_array($query_chat)){
        $chat_array["chat_id"]=$chat_id_array[0];
        $chat_array["sender"]=$chat_id_array[1];
        $chat_array["getter"]=$chat_id_array[2];
        $chat_array["chat_content"]=$chat_id_array[3];
        $chat_array["chat_day"]=$chat_id_array[4];
        $chat_array["chat_time"]=$chat_id_array[5];
        $chat_array["size"]=$chat_id_array[6];
        array_push($array, $chat_array);    
    }
    $response = array();
    $response["success"]=true;
    $response["chat_contentList"]=$array;

    echo json_encode($response, JSON_UNESCAPED_UNICODE);

?>