<?php
    $db_host="localhost";
    $db_user="strawberry";
    $db_password="ckdgns6078!";
    $db_name="strawberry";

    //db 연결
    $con = mysqli_connect($db_host,$db_user,$db_password,$db_name);
    $reply_id = $_POST["reply_id"];

    //보내준 reply_id 를 통해서 posterid 값 찾고 $posterid에 저장
    $sql_reply = "SELECT poster_id FROM reply WHERE reply_id = '$reply_id'";
    $query_reply = mysqli_query($con,$sql_reply);
    $reply_array = mysqli_fetch_array($query_reply);
    $posterid = $reply_array[0];

    //찾은 $posterid를 통해서 choose 컬럼 변경
    $sql_choose = "UPDATE poster SET choose = '$reply_id' WHERE poster_id = '$posterid'";
    $query_choose = mysqli_query($con,$sql_choose);


    mysqli_close($con);
    $response = array();
    $response["success"]=true;

    echo json_encode($response);





?>