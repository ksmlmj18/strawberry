<!-- 게시글 ID 가져오기 -->
<?php
    include "dbcon.php";
    
    // poster_id 가져오기
    $sql = mysqli_query($con, "SELECT poster_id FROM poster");
    
    $poster_idList = [];
    while($row = mysqli_fetch_array($sql)){
        array_push($poster_idList, $row[0]);
    }


    $response = [];
    $response['success'] = true;
    $response['poster_idList'] = $poster_idList;

    mysqli_close($con);

    json_encode($response);
?>