<?php
    $db_host="localhost";
    $db_user="strawberry";
    $db_password="ckdgns6078!";
    $db_name="strawberry";

    $con = mysqli_connect($db_host,$db_user,$db_password,$db_name);
    mysqli_query($con,'SET NAMES utf8');
    
    //형 변환에 사용할 변수들
    $underbar ="-";
    
    //poster_link  //첨부파일 안해 
    // $poster_id //데이터 저장된 마지막 값+1에 저장해야함
    $poster_registrant=$_POST["poster_registrant"];             //작성자 아이디          
    $poster_parentCategory=$_POST["poster_parentCategory"];     //큰 카테고리
    $poster_childCategory=$_POST["poster_childCategory"];       //작은 카테고리
    $poster_title=$_POST["poster_title"];                       //제목
    $poster_content=$_POST["poster_content"];                   //세부 내용
    
    $startYear =$_POST["startYear"];                            //시작 년            
    $startMonth=$_POST["startMonth"];                           //시작 월                     
    $startDay=$_POST["startDay"];                               //시작 일
    $poster_startTime = $startYear . $underbar . $startMonth .$underbar . $startDay; //시작 년,월,일 합친 변수

    $endYear=$_POST["endYear"];                                 //종료 년
    $endMonth=$_POST["endMonth"];                               //종료 월
    $endDay=$_POST["endDay"];                                   //종료 일
    $poster_endTime=$endYear . $underbar . $endMonth . $underbar . $endDay;         //종료 년,월,일 합친 변수

    $maxdate = "SELECT MAX(poster_id) FROM poster";
    $result = mysqli_query($con,$maxdate);
    $row = mysqli_fetch_array($result);
    $poster_id = $row[0]+1;
    

    //SQL 값 8개
    $sql = "INSERT INTO poster( poster_id,poster_registrant,poster_parentCategory,poster_childCategory,poster_title,
                                poster_content,poster_startTime,poster_endTime) VALUES (?,?,?,?,?,?,?,?)";
    $statement = mysqli_prepare($con,$sql);
    mysqli_stmt_bind_param($statement,"isssssss",$poster_id,$poster_registrant,$poster_parentCategory,
                            $poster_childCategory,$poster_title,$poster_content,$poster_startTime,$poster_endTime);
    mysqli_stmt_execute($statement);

    $response = array();
    $response["success"] = true;
    mysqli_close($con);

    echo json_encode($response);

    // $mystring1 = "This is the first string. ";
    // $mystring2 = "This is the second string.";
    // $finalString = $mystring1.$mystring2;
    // echo($finalString);

    


?>