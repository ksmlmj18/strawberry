<?php
    $db_host="localhost";
    $db_user="strawberry";
    $db_password="ckdgns6078!";
    $db_name="strawberry";
    //db 연결
    $con = mysqli_connect($db_host,$db_user,$db_password,$db_name);
    mysqli_query($con, "set names utf8");

    $rating_array = array();
    $get_array = array();
    //닉네임 평점 거래수 경력사항
    // 평점 : rating 거래수 : successNum  경력사항 : user_career
    $sql_info = "SELECT user_nickName,user_rating,user_successNum,user_career FROM user_info";
    $query_info = mysqli_query($con,$sql_info);

    mysqli_close($con);

    while($info_array = mysqli_fetch_array($query_info)){
        $get_array["user_nickName"]=$info_array[0];
        $get_array["user_rating"]=$info_array[1];
        $get_array["user_successNum"]=$info_array[2];
        $get_array["user_career"]=$info_array[3];
        array_push($rating_array,$get_array);
    }

    $response = array();
    $response["success"] = true;
    $response["rating_array"]=$rating_array;

    echo json_encode($response,JSON_UNESCAPED_UNICODE);


?>
