<?php
    
    // 안드로이드 -> 서버 -> DB 채팅 저장하기
    $db_host="localhost";
    $db_user = "strawberry";
    $db_password = "ckdgns6078!";
    $db_name = "strawberry";

    $con = mysqli_connect($db_host,$db_user,$db_password,$db_user);
    mysqli_query($con,'SET NAMES utf8');
 
    $sender = $_POST["sender"];
    $getter = $_POST["getter"];
    $chat_content = $_POST["chat_content"];
    $chat_day = $_POST["chat_day"];
    $chat_time = $_POST["chat_time"];
    $chat_id=1;
    $sql_chatid = "SELECT chat_id FROM chat WHERE sender = '$sender' AND getter ='$getter'
                   OR sender = '$getter' AND getter = '$sender'";
    $query_chatid =mysqli_query($con,$sql_chatid);
            
    if($query_chatid->num_rows>0){
        $chatid_array = mysqli_fetch_array($query_chatid);
        $chat_id = $chatid_array[0];
    }else{
        $sql_max = "SELECT MAX(chat_id) FROM chat";
        $query_max = mysqli_query($con,$sql_max);
        $max_array = mysqli_fetch_array($query_max);
        $chat_id = $max_array[0]+1;
    }

    //채팅방 id의 채팅한 숫자 찾기
    $sql_count = "SELECT MAX(chat_count) FROM chat WHERE chat_id = $chat_id";
    $query_count = mysqli_query($con,$sql_count);
    $count_array = mysqli_fetch_array($query_count);
    $chat_count = $count_array[0]+1;



    $sql_save = "INSERT INTO chat(chat_id,sender,getter,chat_content,chat_day,chat_time,chat_count) VALUES (?,?,?,?,?,?,?)";
    $statement = mysqli_prepare($con,$sql_save);
    mysqli_stmt_bind_param($statement,"isssssi",$chat_id,$sender,$getter,$chat_content,$chat_day,$chat_time,$chat_count);
    mysqli_stmt_execute($statement);

    mysqli_close($con);

    $response = array();
    $response["success"]=true;

    echo json_encode($response);
    
?>