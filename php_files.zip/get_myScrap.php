<?php
    // 마이페이지 -> 스크랩 목록 페이지
    // 로그인 된 user_id == 스크랩 user_id(?) -- 일단 보류
    // 1. 테이블을 수정할건지
    // 2. 자바에서 버튼 클릭한 걸 DB로 보내서, 특수 값을 추가할건지..?
    // 테이블 추가하는 방향이 더 좋아보임.

    include "dbcon.php";

    mysqli_query($con, "set names utf8");


    mysqli_close($con);

    echo json_encode($response, JSON_UNESCAPED_UNICODE);
?>