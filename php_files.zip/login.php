<?php
    // DB 연결
    $db_host = "localhost";
    $db_user = "strawberry";
    $db_password="ckdgns6078!";
    $db_name = "strawberry";

    $con = mysqli_connect($db_host, $db_user, $db_password, $db_name);
    mysqli_query($con, 'SET NAMES utf8');

    // id, pw 값 불러오기
    $user_id = $_POST["user_id"];
    $user_pw = $_POST["user_pw"];
    
    // $statement = mysqli_prepare($con, "SELECT * FROM user_info WHERE user_id = ? AND user_pw = ?");
    // mysqli_stmt_bind_param($statement, "ss", $user_id, $user_pw);
    // mysqli_stmt_execute($statement);

    // mysqli_stmt_store_result($statement);
    // mysqli_stmt_bind_result($statement, $user_id, $user_pw);


    // $response = array();
    // $response["success"] = false;


    // while(mysqli_stmt_fetch($statement)) {
    //     $response["success"] = true;
    //     // $response["user_id"] = true;
    //     // $response["user_pw"] = true;
    // }

    // sql문 작성
    $sql_id = "SELECT user_id FROM user_info WHERE user_id = '$user_id'";
    $sql_pw = "SELECT user_pw FROM user_info WHERE user_pw = '$user_pw'";
    $sql_nick = "SELECT user_nickName FROM user_info WHERE user_id = '$user_id'";
    $sql_info = "SELECT user_id, user_pw, user_nickName FROM user_info WHERE user_id = '$user_id' AND user_pw = '$user_pw'";


    
    // echo "하이"."<br>";
    // sql문 결과 셋
    $res_id = mysqli_query($con, $sql_id);
    $res_pw = mysqli_query($con, $sql_pw);
    $res_nick = mysqli_query($con, $sql_nick);
    $result = mysqli_query($con, $sql_info);


    while($row = mysqli_fetch_array($result)){
        $id = $row[0];
        $pw = $row[1];
        $nick = $row[2];
    }

    // $id = mysqli_fetch_array($res_id);
    // $pw = mysqli_fetch_array($res_pw);
    // $nick = mysqli_fetch_array($res_nick);

    // while($row = mysqli_fetch_array($sql_poster)){  // $sql_poster로 가져온 정보를 한 행씩 $row에 담는다.(없으면 반복 중지)
    //     $poster_info = [];      // 게시물 세부 정보 배열
    //     $poster_info["poster_id"] = $row[0];
    //     $poster_info["parentCategory"] = $row[1];
    //     $poster_info["title"] = $row[2];
    //     $poster_info["content"] = $row[3];
    //     $poster_info["startTime"] = $row[4];
    //     $poster_info["endTime"] = $row[5];
    //     array_push($poster_infoList, $poster_info);         // 2차원 배열로 만듬.
    //     // array_push($poster_info, $row[0], $row[1], $row[2], $row[3], $row[4], $row[5], $row[6]);  // 각 데이터를 한 배열에 넣어주고,
    // }



    // 해당 행 존재 여부 파악
    // echo $res_id -> num_rows;
    // echo $res_pw -> num_rows;
    // echo $res_id -> num_rows;
    // echo $res_pw -> num_rows;
    
    $response = array();
    if($id ==$user_id and $pw ==$user_pw){
        // echo "로그인 성공";
        $response["success"] = true;
        $response["user_id"] = $id;
        $response["user_pw"] = $pw;
        $response["user_nickName"] = $nick;
    }else{
        // echo "로그인 실패";
        $response["success"] = false;
    }

    
    mysqli_close($con);

    echo json_encode($response, JSON_UNESCAPED_UNICODE);
?>