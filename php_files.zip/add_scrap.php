<?php
    // 스크랩 추가하기
    include 'dbcon.php';

    // 닉네임, poster_id
    $user_nickName = $_POST["user_nickName"];
    $poster_id = $_POST["poster_id"];


    $sql_scrapId = "SELECT MAX(scrap_id) FROM scrap WHERE user_nickName = '$user_nickName'";
    $res_scrapId = mysqli_query($con, $sql_scrapId);
    $row_scrap = mysqli_fetch_array($res_scrapId);

    // 스크랩 id
    if($row_scrap[0] != null){
        $scrap_id = $row_scrap[0] + 1;
    }else{
        $scrap_id = 1;
    }
    
    // user_nickName과 스크랩한 poster_id를 받고
    // DB에 추가하기
    $sql_add = "INSERT INTO scrap(scrap_id, user_nickName, poster_id)  VALUES ('$scrap_id', '$user_nickName', '$poster_id')";
    $res_add = mysqli_query($con, $sql_add);

    mysqli_close($con);
    
    $response['success'] = true;
    
    echo json_encode($response, JSON_UNESCAPED_UNICODE);
?>