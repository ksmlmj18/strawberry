<?php
    set_time_limit(0);
    
    $ip ='112.175.184.60';
    $port = 55555;

    $sock = socket_create(AF_INET,SOCK_STREAM,SOL_TCP);
    socket_bind($sock,$ip,$port);
    socket_listen($sock);
    while($client_sock = socket_accept($sock)){
        socket_getpeername($client_sock,$addr,$port2);
        echo "server>> client connected \n";

        $date = "hello";
        socket_write($client_sock,$date);
        socket_close($client_sock);
        echo "SERVER >> client close.\n";


    }
