<?php
    $db_host = "localhost";
    $db_user = "strawberry";
    $db_password = "ckdgns6078!";
    $db_name = "strawberry";

    $con = mysqli_connect($db_host,$db_user,$db_password,$db_name);
    mysqli_query($con, 'SET NAMES utf8');
    
    $user_nickName = $_POST["user_nickName"];        //닉네임
    $user_rating =$_POST["user_rating"];            //평점
    $num=1;


    // DB에 저장된 건수 , 평점을 가져와서 $array에 저장


    $sql_success = "SELECT user_successNum  FROM user_info WHERE user_nickName ='$user_nickName'";
    $query_success = mysqli_query($con,$sql_success);
    $array_success=mysqli_fetch_array($query_success);
    $success = $array_success[0];
    $sql_rating ="SELECT user_rating FROM user_info WHERE user_nickName = '$user_nickName'";
    $query_rating =mysqli_query($con,$sql_rating);
    $array_rating = mysqli_fetch_array($query_rating);
    $rating = $array_rating[0]; 
    
    //0번에 건수successNum  1번에 평점 rating 저장
    if($success==0){
        $sql_update = "UPDATE user_info SET user_successNum ='$num' , user_rating ='$user_rating' WHERE user_nickName = '$user_nickName'";
        mysqli_query($con,$sql_update);
    }else{
        $plus_successNum = $success+$num;
        $value = ($success*$rating+$user_rating)/$plus_successNum;
        $rating2 = round($value,1);
        //round()함수 : $valuse 값의 소수점 1자리까지 표시
        $sql_plusupdate = "UPDATE user_info SET user_successNum = '$plus_successNum', user_rating ='$rating2' WHERE user_nickName ='$user_nickName'";
        mysqli_query($con,$sql_plusupdate);

    
    }
    
    mysqli_close($con);

    $response = array();
    $response["success"]=true;
    echo json_encode($response);
?>